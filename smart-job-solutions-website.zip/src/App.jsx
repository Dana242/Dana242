import React, { useState } from "react";
import { FaFacebook, FaYoutube, FaPhone, FaEnvelope, FaViber, FaTelegram, FaTiktok } from "react-icons/fa";

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [staffs, setStaffs] = useState([
    { id: 1, name: "Staff One" },
    { id: 2, name: "Staff Two" },
    { id: 3, name: "Staff Three" },
    { id: 4, name: "Staff Four" },
    { id: 5, name: "Staff Five" },
    { id: 6, name: "Staff Six" },
    { id: 7, name: "Staff Seven" },
    { id: 8, name: "Staff Eight" },
    { id: 9, name: "Staff Nine" },
    { id: 10, name: "Staff Ten" }
  ]);
  const [photos, setPhotos] = useState([]);
  const [activities, setActivities] = useState([]);

  const handleLogin = () => {
    if (username === "admin" && password === "password123") {
      setLoggedIn(true);
      setError("");
    } else {
      setError("Invalid username or password");
    }
  };

  const handlePhotoUpload = (e) => {
    const files = e.target.files;
    const newPhotos = [];
    for (let i = 0; i < files.length; i++) {
      newPhotos.push(URL.createObjectURL(files[i]));
    }
    setPhotos([...photos, ...newPhotos]);
  };

  const handleActivityAdd = () => {
    const activity = prompt("Enter new activity:");
    if (activity) {
      setActivities([...activities, activity]);
    }
  };

  if (!loggedIn) {
    return (
      <div className="login-screen" style={{ padding: "20px", fontFamily: "Arial, sans-serif" }}>
        <h2>Login to Smart Job Solutions</h2>
        <input placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
        <br />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <br />
        <button onClick={handleLogin}>Login</button>
        {error && <p style={{ color: "red" }}>{error}</p>}
      </div>
    );
  }

  return (
    <div style={{ fontFamily: "Arial, sans-serif", margin: "10px" }}>
      <header style={{ backgroundColor: "#003366", color: "white", padding: "10px", textAlign: "center" }}>
        <h1>Smart Job Solutions</h1>
        <p>Licensed Overseas Employment Agency</p>
      </header>

      <section>
        <h2>Staff List (10+)</h2>
        <ul>
          {staffs.map((staff) => (
            <li key={staff.id}>{staff.name}</li>
          ))}
        </ul>
      </section>

      <section>
        <h2>Upload Photos</h2>
        <input type="file" multiple accept="image/*" onChange={handlePhotoUpload} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: "10px", marginTop: "10px" }}>
          {photos.map((photo, index) => (
            <img key={index} src={photo} alt="Uploaded" width="100" />
          ))}
        </div>
      </section>

      <section>
        <h2>Activities</h2>
        <button onClick={handleActivityAdd}>Add Activity</button>
        <ul>
          {activities.map((activity, index) => (
            <li key={index}>{activity}</li>
          ))}
        </ul>
      </section>

      <section>
        <h2>Social Media & Videos</h2>
        <div>
          <a href="https://www.facebook.com/SJSagency" target="_blank" rel="noopener noreferrer">Facebook</a> |{" "}
          <a href="https://www.youtube.com/@SJSagency" target="_blank" rel="noopener noreferrer">YouTube</a> |{" "}
          <a href="viber://chat?number=%2B959123456789">Viber</a> |{" "}
          <a href="tg://resolve?domain=SJSagency">Telegram</a> |{" "}
          <a href="https://www.tiktok.com/@SJSagency" target="_blank" rel="noopener noreferrer">TikTok</a>
        </div>
        <div style={{ marginTop: "10px" }}>
          <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed?listType=user_uploads&list=SJSagency"
            title="YouTube channel videos"
            frameBorder="0"
            allowFullScreen
          ></iframe>
        </div>
      </section>
    </div>
  );
}