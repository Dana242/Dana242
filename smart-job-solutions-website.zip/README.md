# Smart Job Solutions Website

This is a simple ReactJS project for Smart Job Solutions Overseas Employment Agency.

## Features

- Basic login system (username: admin, password: password123)
- Staff list display (minimum 10 staff members)
- Photo upload with preview
- Activity log (add new activities)
- Embedded YouTube channel videos and social media links (Facebook, Viber, Telegram, TikTok)
- Responsive and simple UI

## How to Run

1. Make sure you have Node.js and npm installed.
2. Clone or download this project.
3. Run `npm install` to install dependencies.
4. Run `npm start` to launch the app.
5. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Login Credentials

- Username: admin
- Password: password123